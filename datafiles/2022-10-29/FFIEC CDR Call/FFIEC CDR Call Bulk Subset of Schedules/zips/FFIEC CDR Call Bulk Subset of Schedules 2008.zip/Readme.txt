This file contains data from Call Reports received and processed by 
the FFIEC Central Data Repository (CDR) as of 2019-11-14T04:30:04 
The file is meant to provide integrated view of financial data 
across the financial institutions filing Call Reports in a format 
that could facilitate the analysis of such data by the public. 
The file may not contain the most recent Call Report and financial 
institutions data available in FFIEC CDR for public access. To 
obtain the most recent publicly available Call Report facsimiles, 
visit the FFIEC CDR Public Data Distribution site. 
  